
********************************************************************************
compas.tolerance
********************************************************************************

.. currentmodule:: compas.tolerance

.. rst-class:: lead


The tolerance module provides functionality to deal with tolerances consistently across all other COMPAS packages.


Classes
=======



.. autosummary::
    :toctree: generated/
    :nosignatures:

    Tolerance


Functions
=========



.. autosummary::
    :toctree: generated/
    :nosignatures:

    TOL



