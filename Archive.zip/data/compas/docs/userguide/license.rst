********************************************************************************
License
********************************************************************************

.. rst-class:: lead

COMPAS is an open source framework with a permissive license such that it can be used
for research as well as for proprietary projects, in academia and in practice,
or at the interface between both.

.. literalinclude:: ../../LICENSE
    :language: none
