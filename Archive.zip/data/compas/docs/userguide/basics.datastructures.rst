********************************************************************************
Datastructures
********************************************************************************

.. toctree::
    :maxdepth: 2
    :titlesonly:
    :caption: Data Structures

    basics.datastructures.graphs
    basics.datastructures.meshes
    basics.datastructures.cells
    basics.datastructures.trees
    basics.datastructures.assemblies
