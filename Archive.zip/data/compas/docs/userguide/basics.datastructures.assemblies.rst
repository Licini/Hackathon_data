********************************************************************************
Assemblies
********************************************************************************

.. note::

    The new (wip) version of the assembly data structure or model is available here
    https://github.com/BRG-research/compas_assembly2.


More information coming soon...
