Developing a Plugin For a Pluggable
===================================
