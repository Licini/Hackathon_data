Implementing a New Data Type
============================
