from __future__ import print_function
from __future__ import absolute_import
from __future__ import division


class ConversionError(Exception):
    """Raised when a conversion is not possible."""
