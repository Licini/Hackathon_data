from __future__ import print_function
from __future__ import absolute_import
from __future__ import division

import scriptcontext as sc  # type: ignore

from compas.scene import GeometryObject
from compas_rhino.conversions import vertices_and_faces_to_rhino
from compas_rhino.conversions import transformation_to_rhino
from .sceneobject import RhinoSceneObject


class RhinoPolyhedronObject(RhinoSceneObject, GeometryObject):
    """Scene object for drawing polyhedron shapes.

    Parameters
    ----------
    polyhedron : :class:`compas.geometry.Polyhedron`
        A COMPAS polyhedron.
    **kwargs : dict, optional
        Additional keyword arguments.

    """

    def __init__(self, polyhedron, **kwargs):
        super(RhinoPolyhedronObject, self).__init__(geometry=polyhedron, **kwargs)

    def draw(self):
        """Draw the polyhedron associated with the scene object.

        Returns
        -------
        list[System.Guid]
            The GUIDs of the objects created in Rhino.

        """
        attr = self.compile_attributes()
        vertices = [list(vertex) for vertex in self.geometry.vertices]
        faces = self.geometry.faces
        geometry = vertices_and_faces_to_rhino(vertices, faces)
        geometry.Transform(transformation_to_rhino(self.worldtransformation))

        self._guids = [sc.doc.Objects.AddMesh(geometry, attr)]
        return self.guids
