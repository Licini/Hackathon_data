# Authors

- Tom Van Mele <<van.mele@arch.ethz.ch>> [@tomvanmele](https://github.com/tomvanmele)
- Li Chen <<li.chen@arch.ethz.ch>> [@Licini](https://github.com/Licini)
- Zac Zhuo Zhang <<zhuo.zhang@arch.ethz.ch>> [@ZacZhangzhuo](https://github.com/ZacZhangzhuo)
