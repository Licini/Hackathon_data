*******************************************************************************
compas_viewer.viewer
*******************************************************************************

.. currentmodule:: compas_viewer.viewer

Classes
=======

.. autosummary::
    :toctree: generated/
    :nosignatures:

    Viewer
    Viewer.add
    Viewer.add_action
