*******************************************************************************
compas_viewer.layout
*******************************************************************************

.. currentmodule:: compas_viewer.layout

Major
=====

.. autosummary::
    :toctree: generated/
    :nosignatures:

    Layout
    WindowLayout
    ViewportLayout
    SidedockLayout
    ToolbarLayout
    MenubarLayout
    StatusbarLayout

Elements
========
.. autosummary::
    :toctree: generated/
    :nosignatures:

    Slider
    Treeform
