*******************************************************************************
compas_viewer.actions
*******************************************************************************

.. currentmodule:: compas_viewer.actions

Classes
=======

.. autosummary::
    :toctree: generated/
    :nosignatures:

    Action
    ZoomSelected
    GLInfo
    SelectAll
    ViewRight
    ViewFront
    ViewTop
    ViewPerspective
    DeleteSelected
