*******************************************************************************
Dynamic
*******************************************************************************

.. autosummary::
    :toctree:
    :nosignatures:
.. figure:: /_images/dynamic.gif
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: dynamic.py
    :language: python
