*******************************************************************************
Orbit Around an Object
*******************************************************************************

.. autosummary::
    :toctree:
    :nosignatures:
.. figure:: /_images/orbiting.gif
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: orbiting.py
    :language: python
