*******************************************************************************
Dynamic Mesh
*******************************************************************************

.. autosummary::
    :toctree:
    :nosignatures:
.. figure:: /_images/dynamic_mesh.gif
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: dynamic_mesh.py
    :language: python
