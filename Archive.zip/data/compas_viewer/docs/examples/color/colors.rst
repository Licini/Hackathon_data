*******************************************************************************
Colors
*******************************************************************************

.. autosummary::
    :toctree:
    :nosignatures:
.. figure:: /_images/colors.jpg
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: colors.py
    :language: python
