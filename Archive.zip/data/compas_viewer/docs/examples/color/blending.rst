*******************************************************************************
Blending
*******************************************************************************

.. autosummary::
    :toctree:
    :nosignatures:
.. figure:: /_images/blending.jpg
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: blending.py
    :language: python
