*******************************************************************************
Face Vertex Color
*******************************************************************************

.. autosummary::
    :toctree:
    :nosignatures:
.. figure:: /_images/face_vertext_color.jpg
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: face_vertext_color.py
    :language: python
