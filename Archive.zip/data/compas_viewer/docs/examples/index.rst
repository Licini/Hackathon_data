
********************************************************************************
Examples
********************************************************************************

.. toctree::
    :maxdepth: 1
    :titlesonly:
    :caption: Basic Examples

    basics
    object
    color
    layout
    dynamic
    other
