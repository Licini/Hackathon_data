*******************************************************************************
Tree View
*******************************************************************************

.. figure:: /_images/tree_view.jpg
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: tree_view.py
    :language: python
