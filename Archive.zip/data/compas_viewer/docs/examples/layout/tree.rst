*******************************************************************************
Tree
*******************************************************************************
.. autosummary::
    :toctree:
    :nosignatures:
.. figure:: /_images/tree.jpg
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: tree.py
    :language: python
