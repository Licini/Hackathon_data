*******************************************************************************
Slider
*******************************************************************************
.. autosummary::
    :toctree:
    :nosignatures:
.. figure:: /_images/slider.gif
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: slider.py
    :language: python
