*******************************************************************************
Property Form
*******************************************************************************

.. figure:: /_images/property_form.gif
    :figclass: figure
    :class: figure-img img-fluid

.. literalinclude:: property_form.py
    :language: python
